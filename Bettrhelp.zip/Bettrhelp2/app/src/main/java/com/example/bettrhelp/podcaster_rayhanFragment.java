package com.example.bettrhelp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView;

public class podcaster_rayhanFragment extends Fragment {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;

    public podcaster_rayhanFragment() {
        // Required empty public constructor
    }

    public static podcaster_rayhanFragment newInstance(String param1, String param2) {
        podcaster_rayhanFragment fragment = new podcaster_rayhanFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_podcaster_rayhan, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Bind YouTubePlayerViews from layout
        YouTubePlayerView video1 = view.findViewById(R.id.video_1);
        YouTubePlayerView video2 = view.findViewById(R.id.video_2);
        YouTubePlayerView video3 = view.findViewById(R.id.video_3);

        // Add lifecycle observer for correct behavior
        getLifecycle().addObserver(video1);
        getLifecycle().addObserver(video2);
        getLifecycle().addObserver(video3);

        // Load each video
        setupYouTubePlayer(video1, "F9EqS5yiLFk");
        setupYouTubePlayer(video2, "rVIn_xeqyfw");
        setupYouTubePlayer(video3, "VGpH7l93Lro");
    }

    private void setupYouTubePlayer(YouTubePlayerView playerView, String videoId) {
        playerView.addYouTubePlayerListener(new AbstractYouTubePlayerListener() {
            @Override
            public void onReady(@NonNull YouTubePlayer youTubePlayer) {
                // Loads the video and waits for play
                youTubePlayer.cueVideo(videoId, 0);
            }
        });
    }
}
