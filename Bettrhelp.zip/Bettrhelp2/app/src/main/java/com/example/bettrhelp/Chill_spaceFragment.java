package com.example.bettrhelp;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.navigation.Navigation;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import android.view.View.OnClickListener;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Chill_spaceFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Chill_spaceFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public Chill_spaceFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Chill_spaceFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static Chill_spaceFragment newInstance(String param1, String param2) {
        Chill_spaceFragment fragment = new Chill_spaceFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_chill_space, container, false);

        // Navigate to Breathing fragment
        View breathingCard = view.findViewById(R.id.breathing_card);
        breathingCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Navigation.findNavController(v).navigate(R.id.action_chillSpace_to_breathing);
            }
        });

        // Navigate to Podcast fragment
        View podcastCard = view.findViewById(R.id.podcast_card);
        podcastCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Navigation.findNavController(v).navigate(R.id.action_chillSpace_to_podcast);
            }
        });

        // ✅ Navigate to Profile fragment
        View profileCard = view.findViewById(R.id.profile_card);
        profileCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Navigation.findNavController(v).navigate(R.id.action_chill_spaceFragment_to_fragment_profile);
            }
        });

        return view;
    }


}