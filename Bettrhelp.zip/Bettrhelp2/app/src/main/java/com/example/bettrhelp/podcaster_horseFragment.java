package com.example.bettrhelp;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView;

public class podcaster_horseFragment extends Fragment {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;

    public podcaster_horseFragment() {
        // Required empty public constructor
    }

    public static podcaster_horseFragment newInstance(String param1, String param2) {
        podcaster_horseFragment fragment = new podcaster_horseFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout
        return inflater.inflate(R.layout.fragment_podcaster_horse, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Find YouTubePlayerViews
        YouTubePlayerView video1 = view.findViewById(R.id.video_1);
        YouTubePlayerView video2 = view.findViewById(R.id.video_2);
        YouTubePlayerView video3 = view.findViewById(R.id.video_3);

        // Attach lifecycle
        getLifecycle().addObserver(video1);
        getLifecycle().addObserver(video2);
        getLifecycle().addObserver(video3);

        // Load videos (replace these IDs with the actual horse-related ones)
        setupYouTubePlayer(video1, "YOUTUBE_VIDEO_ID_1");
        setupYouTubePlayer(video2, "YOUTUBE_VIDEO_ID_2");
        setupYouTubePlayer(video3, "YOUTUBE_VIDEO_ID_3");
    }

    private void setupYouTubePlayer(YouTubePlayerView playerView, String videoId) {
        playerView.addYouTubePlayerListener(new AbstractYouTubePlayerListener() {
            @Override
            public void onReady(@NonNull YouTubePlayer youTubePlayer) {
                youTubePlayer.cueVideo(videoId, 0);
            }
        });
    }
}
