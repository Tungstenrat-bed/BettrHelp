package com.example.bettrhelp;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link podcastFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class podcastFragment extends Fragment {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;

    public podcastFragment() {
        // Required empty public constructor
    }

    public static podcastFragment newInstance(String param1, String param2) {
        podcastFragment fragment = new podcastFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_podcast, container, false);

        // Button for Rayhan
        View buttonRayhan = view.findViewById(R.id.button);
        buttonRayhan.setOnClickListener(v ->
                Navigation.findNavController(v).navigate(R.id.action_podcast_to_rayhan)
        );

        // Button for Horse
        View buttonHorse = view.findViewById(R.id.button2);
        buttonHorse.setOnClickListener(v ->
                Navigation.findNavController(v).navigate(R.id.action_podcast_to_horse)
        );

        return view;
    }
}
